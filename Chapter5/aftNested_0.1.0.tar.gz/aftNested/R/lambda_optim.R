lambda.optim <- function(eff, sm,delta, vpen,mpen, env,val,delta.val,
                         trace=FALSE,init.par, ...){

  force(eff); force(sm); force(vpen);force(mpen)
  force(delta);force(env);force(val); force(delta.val)
  env$coef <- init.par
  env$out <- NULL
  kde <- eff$eval(init.par)$kde

  eff.val <- eff_misi(.predict.matrix.si(sm, val, get.xa = TRUE)$Xi,
                      basis = sm$xt$basis)

  .optim_lambda <- function(rho){
    lambda <- exp(rho)
    llk <- llk_afc(eff, sm = sm, delta = delta, vpen = vpen, mpen = mpen,
                   lambda = lambda, ...)
    llk.val <- llk_afc(eff.val, sm = sm, delta = delta.val, mpen=mpen,
                       vpen = vpen, lambda = lambda, ...)

    out <- nlm(f = llk, p = env$coef, iterlim = 10000)

    out$lambda <- lambda
    sm$coefficients <- out$coefficients <- out$estimate; out$estimate <- NULL
    sm$xt$si$alpha <- out$coefficients[1:length(sm$xt$si$alpha)]
    out$smooth <- sm
    out$formula <- formula
    env$coef <- out$coefficients
    env$out <- out

    loss <- gcv.aft_nl(out, llk.val, kde = kde)
    attr(loss, "gradient") <- attr(loss, "hessian") <-NULL

    ## compute edf
    obj <- eff$eval(param = env$coef, deriv = 3, kde = kde)
    ltx <- log.htx(obj, deriv = 2, delta = delta)
    stx <- log.Stx(obj, deriv = 2)

    Spen <- Reduce("+", lapply(1:length(sm$S), function(ii) lambda[ii]*sm$S[[ii]]))
    # pen <- pen_var_si(o = obj, v = 1, deriv = 2)
    # na <- length(sm$xt$si$alpha)
    # Spen[1:na, 1:na] <- Spen[1:na, 1:na] + vpen*pen$d2

    I <- -ltx$dhab - stx$dhab
    env$out$V <- solve((I + Spen)) #V <- solve(attr(llk(param = sm$coefficients), "hessian"))
    env$out$edf <- diag(I%*%env$out$V)
        # loss <- c(out$minimum + 0.5 *( sum(log(evS[evS>1e-16])) -
    #   0.5 * sum(log(evH[evS>1e-16])) + sm$null.space.dim * log(2*pi) ))
    # print(laml)
    if(trace){
      cat(paste0("iter = ", out$iterations,
                 "\nGCV: ", loss, "  ||   llk = ", env$out$minimum,
                 "\nlambda = ", paste(lambda, collapse = "\t "), "\n\n"))
    }

    return(loss)
  }
  return(.optim_lambda)
}
