# Set seed for reproducibility
set.seed(123)
simulate.data <- function(N, smooth.term = 0){

  beta <- c(1, -1, 1, 1, smooth.term)  # Coefficients for X1, X2, X3, X4
  C2 <- 3  # Administrative censoring time

  # Function to generate event times from a Weibull mixture hazard
  generate_event_time <- function(Z, lambda1, k1, lambda2, k2) {
    if (Z == 0) {
      shape <- k1
      scale <- lambda1
    } else {
      shape <- k2
      scale <- lambda2
    }
    rweibull(1, shape = shape, scale = scale)
  }

  # Step 1: Generate covariates
  Z <- rbinom(N, 1, 0.5)  # Binary covariate Z
  X1 <- rbinom(N, 1, 0.5)  # Binary covariate X1
  X2 <- rbinom(N, 1, 0.5)  # Binary covariate X2
  X3 <- rnorm(N, 0, 1)  # Continuous covariate X3
  X4 <- X3^2  # Strongly correlated continuous covariate X4
  X5 <- rnorm(N, 0, 1)  # Continuous covariate X5

  # Step 2: Generate event times using the AFT model
  W <- rnorm(N, 0, 1)  # Random error term
  log_T <- -(beta[1] * X1 + beta[2] * X2 + beta[3] * X3 +
               beta[4] * X4 + beta[5]*(X5^2)) + W
  Texp <- exp(log_T)

  # Step 3: Generate baseline hazards
  lambda1 <- 5; k1 <- 4  # Weibull parameters for Z = 0
  lambda2 <- 1.5; k2 <- 1.2  # Weibull parameters for Z = 1
  T_baseline <- sapply(Z, generate_event_time, lambda1 = lambda1, k1 = k1,
                       lambda2 = lambda2, k2 = k2)

  # Combine T and T_baseline
  Texp <- Texp * T_baseline  # Combine baseline hazard effect with AFT model

  # Step 4: Generate censoring times
  C1 <- runif(N, 0, C2)  # Random censoring time to achieve ~25% censoring rate
  CC <- pmin(C1, C2)
  Observed_Time <- pmin(Texp, CC)  # Observed time
  Event <- ifelse(Observed_Time < CC, 1, 0)  # Event indicator (1 = event, 0 = censored)

  # Combine all data into a data frame
  data <- data.frame(Z, X1, X2, X3, X4,X5, Texp, C1,
                     Observed_Time, logT = log(Observed_Time),
                     Event, T_baseline)
  return(data)
}

