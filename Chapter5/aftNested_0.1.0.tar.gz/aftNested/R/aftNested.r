#' @importFrom Rcpp evalCpp
#' @exportPattern "^[[:alpha:]]+"
#' @name aftNested
#' @useDynLib aftNested, .registration=TRUE
NULL
