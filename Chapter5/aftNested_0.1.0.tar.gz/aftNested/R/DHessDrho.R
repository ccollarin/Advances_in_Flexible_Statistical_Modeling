DHessDrho <- function(o, llk, DbDr){

#compute dbdr
#compute DhessDrho_htx
#compute DhessDrho_Stx
#
#combine the two
#return

}
