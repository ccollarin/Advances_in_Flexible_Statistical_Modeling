#ifndef ORDER_H
#define ORDER_H

#include <RcppArmadillo.h>
using namespace Rcpp;

//List order_(NumericVector x);
List order_(NumericVector x);

#endif
