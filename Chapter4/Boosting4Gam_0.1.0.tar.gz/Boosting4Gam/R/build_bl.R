#' Base learners constructor
#'
#' @param formula A GAM formula
#' @param data A data frame or list containing the model response variable and
#'             covariates required by the formula.
#' @importFrom mgcv gam
#' @importFrom mgcv predict.gam
#' @importFrom mgcv PredictMat
#'
#' @export
#'
#' @examples
#' n <- 1000
#' x1 <- rnorm(n)
#' x2 <- rnorm(n)
#'
#' y <- x1 + sin(x2) + rnorm(n)
#' dat <- data.frame(y,x1,x2)
#' form <- y~x1+s(x2)
#' bl <- build.bl(form, dat)
build.bl <- function(formula, data, validation, edf = 6){

  terms <- attr(terms(formula), "term.labels")
  lin.terms <- terms[!grepl("\\(", terms)]

  lin.fac <- Xval.lin <- Xval.fac <- NULL
  if(length(lin.terms)>0){
    lin.fac <- lin.terms[sapply(lin.terms, function(tt) is.factor(data[,tt]))]
    lin.terms <- lin.terms[!(lin.terms%in%lin.fac)]
    Xval.lin <- sweep(as.matrix(validation[,lin.terms]), 2,
                      colMeans(as.matrix(validation[,lin.terms])))
    colnames(Xval.lin) <- lin.terms

    if(length(lin.fac)>0){
      Xval.fac <- model.matrix(as.formula(paste0("~0+",
                                     paste0(lin.fac, collapse = "+"))), validation)

      inter.sm <- terms[grepl("\\(", terms)]
      int.fac <- as.logical(rowSums(sapply(lin.fac, function(fc) grepl(fc, inter.sm))))
      if(any(int.fac)){
        formula <- update.formula(formula,
                       as.formula(paste0("~ .-", paste0(inter.sm[int.fac],
                                                       collapse = "-"))))
      }
    }
  } else {lin.terms <- NULL}

  tmp <- gam(formula, data = data, fit = FALSE)
  X <- tmp$X
  Xval <- do.call("cbind", lapply(tmp$smooth,
                                  function(ss) PredictMat(ss, data = validation)))

  Xval <- cbind(1, Xval.lin, Xval.fac, Xval)

  bl <- c(lapply(lin.terms, function(ll){
    out <- list()
    out$X <- dat[,ll] - mean(dat[,ll])
    out$Xval <- validation[,ll]-mean(validation[,ll])
    out$beta <- out$gloss <- 0
    out$term <- ll
    out$type <- "linear"
    out$predict <- function(y, yval = NULL){
      beta <- drop(crossprod(out$X, y)/sum(out$X^2))
      yhat <- unname(out$X*beta)
      loss <- .loss(y, yhat)
      if(!is.null(yval)){
        yhat.val <- unname(out$Xval*beta)
        loss.val <- .loss(yval, yhat.val)
      }else{loss.val <- yhat.val<-  NULL}
      return(list(beta = beta, yhat = yhat,yhat.val=yhat.val,
                  loss = loss, loss.val = loss.val))
    }
    return(out)
  }),
  lapply(lin.fac, function(ll){
    out <- list()
    out$X <- model.matrix(as.formula(paste0("~0+", ll)), data[lin.fac])
    out$Xval <- model.matrix(as.formula(paste0("~0+", ll)), validation[lin.fac])
    out$beta <- rep(0, ncol(out$X))
    out$gloss <- 0
    out$term <- ll
    out$type <- "factor"

    qr.dec <- qr(out$X)
    Q <- qr.Q(qr.dec)
    R <- qr.R(qr.dec)
    rtr <- crossprod(R, R)
    rtrX <- tcrossprod(solve(rtr), out$X)

    out$predict <- function(y, yval = NULL){
      beta <- drop(rtrX%*%y)
      yhat <- unname(out$X%*%beta)
      loss <- .loss(y, yhat)
      if(!is.null(yval)){
        yhat.val <- unname(out$Xval%*%beta)
        loss.val <- .loss(yval, yhat.val)
      }else{loss.val <- yhat.val<-  NULL}
      return(list(beta = beta, yhat = yhat,yhat.val=yhat.val,
                  loss = loss, loss.val = loss.val))
    }
    return(out)
  }),
  lapply(tmp$smooth, function(ss){
    fplp <- ss$first.para:ss$last.para
    out <- list(X = X[,fplp],
                Xval = Xval[,fplp],
                beta = rep(0, length(fplp)),
                gloss = 0,
                term = ss$label)
    qr.dec <- qr(out$X)
    Q <- qr.Q(qr.dec)
    R <- qr.R(qr.dec)
    rtr <- crossprod(R, R)
    S <- ss$S[[1]]
    out$type <- "smooth"

    if(grepl("ti\\(", ss$label)){edf <- 6}
    if(grepl("s\\(", ss$label)){edf <- 4}

    lambda <- nlm(function(lambda){
                  (sum(diag(solve(rtr+exp(lambda) * S)%*%rtr)) - edf)^2
                }, p=log(initial.sp(X = out$X, S = list(S),off=1)))$estimate
    print(sum(diag(solve(rtr+exp(lambda) * S)%*%rtr)))
    rtr <- tcrossprod(solve(rtr+exp(lambda) * S), out$X) # (t(X)%*%X)^-1%*%t(X)

    out$predict <- function(y, yval = NULL){
      beta <- drop(rtr%*%y)
      yhat <- drop(out$X%*%beta)
      loss <- .loss(y, yhat)
      if(!is.null(yval)){
        yhat.val <- unname(out$Xval%*%beta)
        loss.val <- .loss(yval, yhat.val)
      }else{loss.val <- yhat.val <-  NULL}
      return(list(beta = beta, yhat = unname(yhat), yhat.val = unname(yhat.val),
                  loss = loss, loss.val = loss.val))
    }
    out$lambda = exp(lambda)
    return(out)
  }))
  names(bl) <- attr(terms(formula),"term.labels")
  return(bl)

}
