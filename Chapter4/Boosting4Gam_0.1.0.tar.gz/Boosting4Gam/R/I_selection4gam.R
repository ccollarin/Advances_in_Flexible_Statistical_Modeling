#' Effects selector
#'
#' @param fit fitted model via gb2l
#' @param type type of selector desired
#'
#' @importFrom glmnet cv.glmnet
#' @export

.selection4gam <- function(fit, type = "lasso"){
  X <- do.call("cbind",
              lapply(fit$baselearners,
                     function(bb) bb$X%*%as.matrix(bb$beta)))
  Xval <- do.call("cbind",
              lapply(fit$baselearners,
                     function(bb) bb$Xval%*%as.matrix(bb$beta)))
  y <- fit$y - fit$intercept
  yval <- fit$yval - fit$intercept

  if(type == "lasso"){
    #mod.lasso <- cv.glmnet(x = X, y = fit$y)
    mod.lasso <- cv.glmnet(x = Xval, y = yval)
    non0 <- which(as.vector(coef(mod.lasso)>0))[-1]-1
    selected <- sapply(fit$baselearners, "[[", "term")[non0]
  }
  if(type == "l0"){
    pi <- fit$gained.loss/sum(fit$gained.loss)
    gamma <- unique(sort(pi)[-length(pi)])

    gamma.optim <- function(gg, q, X, y){
      out <- list()
      out$pi <- sapply(q, function(qq) max(qq-gg, 0))
      out$pi <- out$pi/sum(out$pi)
      tt <- rowSums(X[, out$pi>0, drop = FALSE])
      out$loss <- sum((tt-y)^2)
      return(out)
    }
    optgamma <- lapply(gamma, function(gg) gamma.optim(gg, q = pi, X = Xval, y = yval))
    best <- length(gamma) - which.min(rev(sapply(optgamma, "[[", "loss")))+1
    selected <- sapply(fit$baselearners, "[[", "term")[optgamma[[best]]$pi>0]
  }

  return(list(effects = selected,
              vars = gsub(".*\\((.*)\\).*", "\\1", selected)))

}
