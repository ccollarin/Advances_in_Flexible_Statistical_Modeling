.loss <- function(y1,y2){
  sum((y1-y2)^2)
}
