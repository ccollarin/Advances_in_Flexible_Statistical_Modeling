#' Title
#'
#' @param sm smooth
#' @param X data
#' @param edf degrees of freedom
#' @param range_l range
#'
#' @return base_learner
#' @export
#'
base_learners <- function(sm, X, edf, range_l = c(-5,5)){
  ## base learner constructor - takes a smooth and returns base learner for it,
  ## seaking to make effective degrees of freedom edf + null.space.dim
  if (length(sm$first.para) == 0){index <- 1:ncol(X)
  } else { index <- sm$first.para : sm$last.para }
  X <- X[,index]
  n <- nrow(X); m <- length(sm$S)
  lambda <- rep(0,m)
  for (i in 1:m) { ## balance penalties
    index <- !(rowSums(sm$S[[i]]!=0)==0)
    lambda[i] <- sum(X[,index]^2)/sum(sm$S[[i]]^2)^.5
  }
  S <- sm$S[[1]]*lambda[i]
  if (m>1) for (i in 2:m) S <- S + lambda[i]*sm$S[[i]]
  ## search for s.p. giving target EDF...
  er <- uniroot(rf, range_l, X = X, S = S, n = n,
                edf = edf + sm$null.space.dim, tol = .01)
  Qf <- attr(er$f.root,"Qf")
  R <- attr(er$f.root,"R")
  list(Qf = Qf, R = R)
}
