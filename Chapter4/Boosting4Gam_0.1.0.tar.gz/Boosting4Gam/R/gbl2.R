gbl2 <- function(formula, data, maxit = 5000, nu.type = 0.1, validation = NULL){
  if(is.null(validation)){
    val.set <- sample.int(n = nrow(data), size = nrow(data)/10)
    validation <- data[val.set,]
    data <- data[-val.set,]
  }
  bl <- build.bl(formula, data, validation)
  y <- data[[formula[[2]]]]
  yval <- validation[[formula[[2]]]]
  #1. initialization
  yhat <- rep(mean(y), length.out = length(y))
  yhat.val <- rep(mean(y), length.out = length(yval))
  betas <- unlist(sapply(bl, "[[", "beta"))
  m=0
  update.max <- TRUE
  out <- list(intercept = mean(y))
  for(m in 1:maxit){
    #2.compute residuals
    res <- y-yhat
    res.val <- yval-yhat.val
    loss <- .loss(y,yhat)
    loss.val <- .loss(yval,yhat.val)
    #3.Projection of gradient to learner
    fitted.bl <- lapply(bl, function(bb) bb$predict(res))
    best.bl <- which.min(sapply(fitted.bl,"[[", "loss"))

    #4.update
    if(grepl("ad", nu.type)){
      # print(cov(res, fitted.bl[[best.bl]]$yhat))
      nu <- abs(cov(res, fitted.bl[[best.bl]]$yhat))
      #if(nu<1e-1) nu <- .1
    }else{
      nu <- as.numeric(nu.type)
    }
    bl[[best.bl]]$beta <- bl[[best.bl]]$beta + nu*fitted.bl[[best.bl]]$beta
    yhat <- yhat + nu*fitted.bl[[best.bl]]$yhat
    yhat.val <- yhat.val + nu*bl[[best.bl]]$predict(y,yval)$yhat.val


    bl[[best.bl]]$gloss <- bl[[best.bl]]$gloss +
      (loss - .loss(y, yhat))
    betas <- unlist(sapply(bl, "[[", "beta"))

    # if(loss.val<.loss(yval,yhat.val) & update.max){
    #   maxit <- ceiling(m + m)
    #   update.max <- FALSE
    # }
    # if(!update.max & m==maxit){break}
    if(cov(res, fitted.bl[[best.bl]]$yhat)/cov(y,yhat) < .01 )
      break


  }

  out$m <- m
  out$betas <- betas
  out$y <- y
  out$yval <- yval
  out$fitted.values <- yhat
  out$residuals <- res
  out$baselearners <- bl
  out$X <- do.call("cbind", lapply(bl, "[[", "X"))
  out$gained.loss <- sapply(bl, "[[", "gloss")
  out$loss <- loss
  out$loss.val <- .loss(yval,yhat.val)

  return(out)
}
