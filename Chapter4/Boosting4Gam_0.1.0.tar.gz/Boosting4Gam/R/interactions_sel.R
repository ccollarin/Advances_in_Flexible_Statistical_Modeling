interactions.sel <- function(formula, data, val, type = "lasso", nu.type = .1, verbose = TRUE){
  o <- list()
  o$fit1 <- gbl2(formula, data, nu.type=nu.type, validation = val)
  vars <- unname(names(o$fit1$gained.loss)[o$fit1$gained.loss>0])
  if(verbose){
    cat(cat(paste0("\n-- STEP 1 --",
                   "\niter = ", o$fit1$m,
                   "\nloss: ", o$fit1$loss,
                   "  ||   loss.val = ", o$fit1$loss.val,
                   "\nselected effects\n",
                   paste(vars, collapse=", "))))
  }

  o$cov1 <- .selection4gam(o$fit, type = type)
  if(verbose){
    cat(cat(paste0("\n\n-- STEP 2 --",
                   "\nselected effects\n",
                   paste(o$cov1$effects, collapse=", "))))
  }
  if(length(unique(o$cov1$vars))<=1){
    if(length(vars) <= 1){
      vars <- attr(terms(formula), "term.labels")
    }
    interactions <- .get.ti(vars)
  }else{
    interactions <- .get.ti(unique(names(o$cov1$vars)))
  }
  o$formula2 <- as.formula(paste(all.vars(formula)[1], "~ ",
                            paste0(c(names(o$cov1$vars),  interactions),  collapse = "+")))
  o$fit2 <- gbl2(o$formula2, data,nu.type=nu.type)
  vars <- unname(names(o$fit2$gained.loss)[o$fit2$gained.loss>0])
  if(verbose){
    cat(cat(paste0("\n\n-- STEP 3 --",
                   "\niter = ", o$fit2$m,
                   "\nloss: ", o$fit2$loss,
                   "  ||   loss.val = ", o$fit2$loss.val,
                   "\nselected effects\n",
                   paste(vars, collapse=", "))))
  }
  o$cov2 <- .selection4gam(o$fit2, type = type)
  if(verbose){
    cat(cat(paste0("\n\n-- STEP 4 --",
                   "\nselected effects\n",
                   paste(o$cov2$effects, collapse=", "))))
  }
  if(length(o$cov2$effects)>0){
    o$final.formula <- as.formula(paste(all.vars(formula)[1], "~ ",
                                   paste0(names(o$cov2$vars),  collapse = "+")))
  }else {o$final.formula <- paste(all.vars(formula)[1], "~ ", paste0(vars, collapse = "+"))}

  return(o)
}
