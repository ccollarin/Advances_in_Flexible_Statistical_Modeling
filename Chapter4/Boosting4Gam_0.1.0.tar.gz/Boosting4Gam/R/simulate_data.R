#' Simulate example data for GAMs
#'
#' @param eg numeric value specifying the example required.
#' @param n number of data to simulate.
#' @param d number of covariates to simulate
#' @param scale Used to set noise level
#'
#' @return A dataframe n x (d+1) containing the response y and covariates.
#' @importFrom stats runif
#' @importFrom stats rnorm
#' @export
#'
#' @examples
#' eg <- 1
#' n <- 1000
#' d <- 10
#' scale <- 1
#'
#' dat <- simulate_data(eg,n,d,scale)
#' dim(dat)
#' par(mfrow = c(2,2))
#' plot(y~x0, data = dat)
#' plot(y~x1, data = dat)
#' plot(y~x2, data = dat)
#'
simulate_data <- function(eg, n, d, scale){

  if (eg == 1){## 4 term Gu  and Wahba example
    if(d<3){stop("with eg = 1, d has to be at least 3")}

    X <- .generate_X(n = n, ncol = d)

    f0 <- function(x) 2 * sin(pi * x)
    f1 <- function(x) exp(2 * x)
    f2 <- function(x) 0.2 * x^11 * (10 * (1 - x))^6 + 10 *
      (10 * x)^3 * (1 - x)^10
    f3 <- function(x) 0 * x
    f <- f0(X[,1]) + f1(X[,2]) + f2(X[,3]) + f3(X[,4])

  } else if (eg == 2){## bivariate example
    if(d<5){stop("with eg = 2, d has to be at least 5")}
    X <- .generate_X(n = n, ncol = d)

    f0 <- function(x) 10*x
    f1 <- function(x) x^4
    f2 <- function(x) 0.5 * exp(2*(x+1))
    f34 <- function(x,y)  -0.5*(3*cos(y + x) - 2*sin(y))^4

    f <- f0(X[,1]) + f1(X[,2]) + f2(X[,3]) + f34(X[,4], X[,5])
  }else if(eg==3){## single index example
    if(d<5){stop("with eg = 3, d has to be at least 5")}
    X <- .generate_X(n = n, ncol = d, range_x = c(-4,4))

    f0 <- function(x) sin(x/2)
    f1 <- function(x) 0.5*exp(x/4)
    f2 <- function(x) 0.5 * x + sin(x)

    p <- 3
    x2x3x4 <- X[,3:5]
    X[,3:5] <- NULL
    X <- data.frame(X)
    X$x2x3x4 <- x2x3x4
    z <- as.matrix(X[,3:5]) %*% (1:p) / sum(1:p)             # construct the single index

    f <- f0(X[,1]) + f1(X[,2]) + f2(z)
  }

  data <- data.frame(y = f + rnorm(n, sd = scale), X=X)
  colnames(data) <- c("y", colnames(X))

  return(data)
}

#' @keywords internal
.generate_X <- function(n, ncol, range_x = c(0,1)){
  X <- matrix(runif(n * ncol, range_x[1], range_x[2]), ncol = ncol)
  X <- data.frame(X)
  colnames(X) <- paste0('x', 0:(ncol - 1))
  return(X)
}
