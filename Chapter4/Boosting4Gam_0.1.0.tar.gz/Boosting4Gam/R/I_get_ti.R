.get.ti <- function(vars){
  # Function to extract variable names and k values
  extract_info <- function(x) {
    var <- gsub(".*\\((.*?)(,.*|\\))", "\\1", x)  # Extract between ( and first , or )
    k <- ifelse(grepl("k ?=", x), gsub(".*k ?= ?([0-9]+).*", "\\1", x), NA)  # Extract k value
    list(var = var, k = as.numeric(k))
  }

  # Extract information for all strings
  info <- lapply(vars, extract_info)

  # Create a data frame for clarity
  info_df <- do.call(rbind, lapply(info, as.data.frame))
  info_df <- data.frame(variable = unlist(info_df$var), k = unlist(info_df$k))

  # Generate all possible combinations of variables
  combinations <- combn(info_df$variable, 2, simplify = FALSE)

  # Build ti() expressions
  result <- sapply(combinations, function(pair) {
    # Get the corresponding k values for the variables
    k_values <- info_df$k[info_df$variable %in% pair]
    k_part <- if (all(is.na(k_values))) "" else paste0(", k = c(", paste(na.omit(k_values), collapse = ","), ")")

    # Construct the ti() expression
    paste0("ti(", paste(pair, collapse = ", "), k_part, ")")
  })

  # Print the results
  return(result)

}

